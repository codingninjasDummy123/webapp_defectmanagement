import { Component, OnInit } from '@angular/core';
import { Defect } from '../services/defect';
import { DefectService } from '../services/defect.service';
 
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  totalDefects: number = 0;
  defectsByPriority: { priority: string, count: number }[] = [];
  unresolvedDefects: number = 0;
 
  constructor(private defectService: DefectService) { }
 
  ngOnInit() {
    this.fetchDefectData();
  }
 
  fetchDefectData() {
    this.defectService.getAllDefects().subscribe((defects: Defect[]) => {
      // Total defects count
      this.totalDefects = defects.length;
 
      // Defects by priority
      const priorities = defects.map(defect => defect.priority);
      this.defectsByPriority = [...new Set(priorities)].map(priority => ({
        priority,
        count: priorities.filter(p => p === priority).length
      }));
 
      // Unresolved defects count
      this.unresolvedDefects = defects.filter(defect => defect.status !== 'Resolved').length;
    });
  }
}