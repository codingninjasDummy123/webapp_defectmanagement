package com.cognizant.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@ComponentScan("com.cognizant")
@SpringBootApplication(scanBasePackages="com.cognizant.*")
@EntityScan(basePackages="com.cognizant.entities")
@EnableJpaRepositories(basePackages="com.cognizant.repositries")
public class DefectsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DefectsManagementApplication.class, args);
	}

}
