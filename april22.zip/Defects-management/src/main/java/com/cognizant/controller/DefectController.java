package com.cognizant.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.dto.DefectDTO;
import com.cognizant.dto.DefectDetailsDTO;
import com.cognizant.dto.DefectReportDTO;
import com.cognizant.dto.UpdateDefectDTO;
import com.cognizant.entities.Defect;
import com.cognizant.services.DefectService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api")
@CrossOrigin(origins = "http://localhost:4200")
/**
 * @author K
		**/
public class DefectController {

	@Autowired
    private DefectService defectService;

	@PostMapping("defects/new")
	public ResponseEntity<?> createDefect(@Valid @RequestBody DefectDTO defectDTO) throws Exception {
	    System.out.println(defectDTO);
	    String result = defectService.createDefect(defectDTO);
	    if (result.equals("success")) {
	        return ResponseEntity.status(HttpStatus.CREATED).body("{\"message\": \"Success\"}");
	    } else if (result.equals("Developer has reached the maximum bug assignment limit for today")) {
	        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("{\"error\": \"Maximum bug assignment limit reached for today.\"}");
	    } else {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\": \"" + result + "\"}");
	    }
	}
    @PutMapping("/defects/resolve")
    public ResponseEntity<String> resolveDefect(@RequestBody UpdateDefectDTO defectDTO) throws Exception {
        String status = defectService.updateDefect(defectDTO);
        if (status.equals("Defect updated successfully")) {
            return new ResponseEntity<>(status, HttpStatus.OK);
        } else if(status.equals("Defect not found")) {
        	throw new Exception("Defect Not found Exception");
        }else  return new ResponseEntity<>(status, HttpStatus.NOT_FOUND);

    }
    @GetMapping("/defects/assignedto/{developerId}")
    public ResponseEntity<List<Defect>> getDefectsByDeveloper(@PathVariable String developerId) throws Exception {
        List<Defect> defects = defectService.findDefectsByDeveloper(developerId);
        return ResponseEntity.ok(defects);
    }
    
    
    @GetMapping("/defects/{defectId}")
    public ResponseEntity<DefectDetailsDTO> getDefectDetails(@PathVariable Integer defectId) throws RuntimeException, Exception {
    	Defect defect = defectService.findDefectById(defectId).orElseThrow(() -> new RuntimeException("Defect not found with id " + defectId));
        DefectDetailsDTO defectDetailsDTO = new DefectDetailsDTO();
        defectDetailsDTO.setId(defect.getId());
        defectDetailsDTO.setTitle(defect.getTitle());
        defectDetailsDTO.setDefectdetails(defect.getDefectdetails());
        defectDetailsDTO.setStepstoreproduce(defect.getStepstoreproduce());
        defectDetailsDTO.setPriority(defect.getPriority());
        defectDetailsDTO.setDetectedon(defect.getDetectedon());
        defectDetailsDTO.setExpectedresolution(defect.getExpectedresolution());
        defectDetailsDTO.setReportedbytesterid(defect.getReportedbytesterid());
        defectDetailsDTO.setAssignedtodeveloperid(defect.getAssignedtodeveloperid());
        defectDetailsDTO.setSeverity(defect.getSeverity());
        defectDetailsDTO.setStatus(defect.getStatus());
        defectDetailsDTO.setProjectcode(defect.getProjectcode());
        defectDetailsDTO.setResolutions(defect.getResolutions());

        return ResponseEntity.ok(defectDetailsDTO);
    }
    
    @GetMapping("/defects/report/{projectId}")
    public ResponseEntity<DefectReportDTO> getDefectReport(@PathVariable int projectId) throws Exception {
        DefectReportDTO defectReportDTO = defectService.generateDefectReport(projectId);
        return new ResponseEntity<>(defectReportDTO, HttpStatus.OK);
    }
    @GetMapping("/defects/getAll")
    public ResponseEntity<List<DefectDTO>> getAllDefects() {
        List<DefectDTO> defects = defectService.getAllDefects();
        return new ResponseEntity<>(defects, HttpStatus.OK);
    }

}


