insert into users values('kartik','kartik123','developer',false);
insert into users values('amaey','amaey123','productowner',false);
insert into users values('harsh','harsh123','tester',false);
insert into users values('tahleel','tahleel123','tester',false);